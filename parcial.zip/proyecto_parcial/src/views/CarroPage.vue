<template>
    <ion-page>
      <ion-header :translucent="true">
        <ion-toolbar>
          <ion-title>carro</ion-title>
        </ion-toolbar>
      </ion-header>  
      <ion-content>       
        <div id="login-container">  
          <div id="login-form">
            <InputComponent id="id" name="id" type="hidden"/>
            <InputComponent id="marca" name="marca" label="marca: "  />
            <InputComponent id="modelo" name="modelo" label="modelo: " />
            <InputComponent id="placa" name="placa" label="placa: " />
            <InputComponent  id="color" name="color" label="color: " />
        
          </div>
          <div>
            <CrudButtonComponent/>
      

          </div>
        

  
             
        </div>
      </ion-content>
    </ion-page>
  </template>
  
  <script setup lang="ts">
  import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/vue';
  import InputComponent from '@/Components/InputComponent.vue';
  
import CrudButtonComponent from '@/Components/CrudButtonComponent.vue';


  </script>
  
  <style scoped src="../theme/container.css"></style>
