<template>
  <ButtonComponent id="created" value="Agregar" expand="full" color="warning" />
  <ButtonComponent id="updated" value="Modificar" expand="full" color="warning" />
  <ButtonComponent id="deleted" value="Eliminar" expand="full" color="warning" />
  <ButtonComponent id="find" value="Consultar" expand="full" color="warning" />
  <ButtonComponent id="Atras" value="Atras" expand="full"  />

</template>

<script setup lang="ts">
import ButtonComponent from './ButtonComponent.vue';
</script>

<style scoped src="../theme/container.css"></style>
